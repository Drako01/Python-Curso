from constantes import MI_CONSTANTE
from constantes import Matematicas as Mate

print(MI_CONSTANTE)
print(Mate.PI)

# No debemos cambiar el valor de una constante
# MI_CONSTANTE = 'Nuevo valor'
# print(MI_CONSTANTE)