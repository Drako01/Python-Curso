MI_CONSTANTE = 'Valor de mi constante'

class Matematicas:
    PI = 3.1416